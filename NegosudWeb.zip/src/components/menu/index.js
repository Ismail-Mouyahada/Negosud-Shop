import MenuDesktop from '@/components/menu/MenuDesktop';
import MobileNav from '@/components/menu/MobileNav';

export default [
    MenuDesktop,
    MobileNav
]