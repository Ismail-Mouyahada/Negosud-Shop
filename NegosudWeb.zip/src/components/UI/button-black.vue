<template>
  <button type="submit" class="btn-black">
    <slot> </slot>
  </button>
</template>

<script>
export default {
  name: "btn-black",
};
</script>

<style lang="scss" scoped>
@import "@/styles/scss/variables";
.btn-black {
  padding: 1.5em 4em;
  background: #b7cb15;
  border-radius: 1em;
  border: none;
  font-size: 13px;
  font-weight: 400;
  font-family: "Comfortaa", Arial;
  line-height: 14px;
  text-align: center;
  text-transform: uppercase;
  color: #fff;
  cursor: pointer;
}
</style>
