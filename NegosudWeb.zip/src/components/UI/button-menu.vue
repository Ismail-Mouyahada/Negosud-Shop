<template>
  <button class="btn-reset button-menu" type="button" />
</template>

<script>
export default {
  name: "button-menu",
};
</script>

<style lang="scss" scoped>
.button-menu {
  width: fit-content;
  background-image: url("@/assets/menu.svg");
  background-repeat: no-repeat;
  background-position: center;
}
</style>
