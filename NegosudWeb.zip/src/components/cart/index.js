import Cart from '@/components/cart/Cart.vue';

export default [
    Cart
]