import HeaderFooterLayout from '@/layouts/HeaderFooterLayout.vue';

export default [
    HeaderFooterLayout
]